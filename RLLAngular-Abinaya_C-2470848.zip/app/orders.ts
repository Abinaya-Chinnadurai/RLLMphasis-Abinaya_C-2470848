export class Orders {
        public  ord_id : number;
		public  cus_id : number;
		public  ven_id : number;
		public  wal_source : string;
		public  men_id : number;
		public  ord_date : Date;
		public  ord_quantity : number;
		public  ord_billamount : number;
		public  ord_status : string;
		public  ord_comments : string;
}
