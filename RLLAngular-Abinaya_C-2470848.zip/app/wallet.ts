export class Wallet {
    public  cus_id:number;
    public  wal_id:number;
    public  wal_amount:number;
    public  wal_source:string;
    constructor(){
        
    }
}
