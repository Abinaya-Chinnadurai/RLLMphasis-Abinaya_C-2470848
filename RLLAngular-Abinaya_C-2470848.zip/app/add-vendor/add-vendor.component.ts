import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Vendor } from '../vendor';
import { VendorService } from '../vendor.service';

@Component({
  selector: 'app-add-vendor',
  templateUrl: './add-vendor.component.html',
  styleUrls: ['./add-vendor.component.css']
})
export class AddVendorComponent implements OnInit {

  vendordetails:Vendor;
  isFormSubmitted : boolean;
  isValid : boolean
  signup(signupForm : NgForm) {

    if (signupForm.invalid) {
      
      return;
      
    }
    
    this.isValid=true;
    if(this.isValid==true){
    this._vendorService.addVendor(this.vendordetails).subscribe(x => {
    });
    alert("Vendor Registration Successful!");
    this._router.navigate(['/VendorLogin']);
  }
}
    
  constructor(private _vendorService:VendorService,private _router : Router) {
this.vendordetails=new Vendor();
this.isFormSubmitted = false;
this.isValid=false;

   }

  //  addVendor(){

  //    this._vendorService.addVendor(this.vendordetails).subscribe(x => {
  //    });
  //    alert("Vendor added");
   
  // }

  

  ngOnInit(): void {
  }

}
