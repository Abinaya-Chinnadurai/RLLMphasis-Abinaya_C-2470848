import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { ObjectUnsubscribedError, Observable } from 'rxjs';
import { Customer } from '../customer';
import { Menu } from '../menu';
import { MenuService } from '../menu.service';
import { Orders } from '../orders';
import { OrdersService } from '../orders.service';
import { Vendor } from '../vendor';
import { VendorService } from '../vendor.service';
import { Wallet } from '../wallet';
import { WalletService } from '../wallet.service';

@Component({
  selector: 'app-place-order',
  templateUrl: './place-order.component.html',
  styleUrls: ['./place-order.component.css']
})
export class PlaceOrderComponent implements OnInit {
 cus:Customer;
 orderdetails:Orders;
 menu:Observable<Menu[]>;
 menufound:Menu;
 price:number;
 vendor:Observable<Vendor[]>;
 wallet:Observable<Wallet[]>;
msg:string;

 placeOrder() {
   //alert("hello");
   this.orderdetails.ord_billamount= this.orderdetails.ord_quantity*this.price;
   if(this.orderdetails.ord_quantity <1 ){
     alert("More quantity needed")
    }else{
    this._orderService.placeOrder(this.orderdetails).subscribe(x => {
    this.msg = x;
    alert(this.msg);
  })}
  this._router.navigate(['CustomerDashboard']);
}
  constructor(private _menuService:MenuService, private _vendorService:VendorService, private _walletService:WalletService, 
    private _router : Router ,private _orderService:OrdersService) {
    this.orderdetails= new Orders(); 
    this.cus = localStorage.getItem('customerData')?JSON.parse(localStorage.getItem('customerData')):[]
   // alert(this.cus.cus_id);
    this.orderdetails.cus_id=this.cus.cus_id;
    this.menu=this._menuService.showMenu();
    this.vendor= this._vendorService.showVendors();
    this.wallet= this._walletService.showCustomerWallets(this.cus.cus_id);
    this.todayDate = new Date();
   }
   showAmount(){
    //alert(this.orderdetails.men_id);
    this._menuService.searchMenu(this.orderdetails.men_id).subscribe(x => {
      this.menufound = x;
      this.price= x.men_price;      
    });
   }
  ngOnInit(): void {
    this.getDate();
  }

  todayDate : any 

    getDate() {

      var date:any = new Date();
      
      var toDate:any = date.getDate();
      
      if(toDate < 10) {
      
      toDate = 'e' + toDate;
      
      }
      
      var month: any  = date.getMonth() + 1;
      
      if(month < 10){
      
      month= '0' + month;
      
      }
      
      var year = date.getFullYear();
      
      this.todayDate = year + "-" + month + "-" +toDate
      console.log(this.todayDate)
  }

}
